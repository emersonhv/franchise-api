# Franchise API

## Descripción
API para manejar franquicias, sucursales y productos usando Spring Boot, MySQL y Redis.

## Requisitos
- Docker
- Docker Compose

## Despliegue
1. Construir el proyecto:
   ```bash
   ./mvnw clean package